
import './Style.css'
import { Link } from 'react-router-dom'
const Navigation=()=>
{
    return(
      <>
     <nav>
          <header class="container parent ">

             <section class="mx-auto  d-flex justify-content-between align-item-center">

                <span class="fw-bold "><img src="image/icons/logo7.png" alt="" /></span>
                <span class="d-lg-none fw-bold" data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop">
                <i class="bi bi-three-dots"></i>
                </span>
             <ul className='bg p-4 w-75 d-none justify-content-evenly mx-auto'>
                   <li>
                   <Link to="/" className='one text-dark fs-5'>Home</Link>
                   </li>
                   <li>
                   <Link to="/About" className='one text-dark fs-5'>About</Link>
                   </li>
                   <li>
                   <Link to="/Classes" className='one text-dark fs-5'>Classes</Link>
                   </li>
                   <li>
                   <Link to="/Gallery" className='one text-dark fs-5'>Gallery</Link>
                   </li>
                   <li>
                   <Link to="/Blog" className='one text-dark fs-5'>Blog</Link>
                   </li>
                   <li>
                   <Link to="/Contact" className='one text-dark fs-5'>Contact</Link>
                   </li>
            </ul>
            
            </section>
        </header>
    </nav>
    
  
      <nav>
          <header class="container parent ">
             <section class="mx-auto  d-flex justify-content-between align-item-center">
                <span class="fw-bold "> <img src="image/icons/logo.webp" alt="" width="100px" height="50px"/></span>
                <span class="d-lg-none fw-bold" data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop">
                </span>
                
                   <div>
                  
                   </div>
                     <ul class="d-none d-lg-block d-lg-flex justify-content-around w-50 h-25 pt-3 list-unstyled">

                     <li>
                   <Link to="/" className='one text-dark fs-5'>Home</Link>
                   </li>
                   <li>
                   <Link to="/About" className='one text-dark fs-5'>About</Link>
                   </li>
                   <li>
                   <Link to="/Classes" className='one text-dark fs-5'>Classes</Link>
                   </li>
                   <li>
                   <Link to="/Gallery" className='one text-dark fs-5'>Gallery</Link>
                   </li>
                   <li>
                   <Link to="/Blog" className='one text-dark fs-5'>Blog</Link>
                   </li>
                   <li>
                   <Link to="/Contact" className='one text-dark fs-5'>Contact</Link>
                   </li>
                     </ul>
                     
            </section>
        </header>
    </nav>
            <div class="offcanvas offcanvas-Top bg-light" id="offcanvasTop">
                <div class="offcanvas-header">
                     <h5 id=" offcanvas-Top label">menu</h5>
                     <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                </div>
                     <div class="offcanvas-body">
               
                        <ul class="list-unstyled">
                  
                        <li>
                   <Link to="/" className='one text-dark fs-5'>Home</Link>
                   </li>
                   <li>
                   <Link to="/About" className='one text-dark fs-5'>About</Link>
                   </li>
                   <li>
                   <Link to="/Classes" className='one text-dark fs-5'>Classes</Link>
                   </li>
                   <li>
                   <Link to="/Gallery" className='one text-dark fs-5'>Gallery</Link>
                   </li>
                   <li>
                   <Link to="/Blog" className='one text-dark fs-5'>Blog</Link>
                   </li>
                   <li>
                   <Link to="/Contact" className='one text-dark fs-5'>Contact</Link>
                   </li>
                           
                </ul>       
                     </div>
            </div>
    
    
      </>
    )
  }
    export default Navigation
    