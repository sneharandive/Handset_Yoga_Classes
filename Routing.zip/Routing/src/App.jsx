
import { BrowserRouter, Route, Routes } from "react-router-dom"
import Navigation from "./Navigation"
import Home from "./Home"
import About from "./About"
import Blog from "./Blog"
import Contact from "./Contact"
import Galleryy from "./Galleryy"
import Classes from "./Classes"


function App() {


  const Homm=[
    { 
       text:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer auctor pharetra iss neque. Nullam cursus elit sit amet justo interdum facilisis id at tortor. ',
       one:'Welcome Our Handstand',
      // home end
       abouthead:'About Our Handstand',
       aboutpara:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum issss has been the industrys standard dummy text ever since the 1500s, when an unknown lorem printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, lorem ipsum is but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and is more recently with desktop publishing software like Aldus PageMaker including versions.',
     //  about end
       classhead:'Our Classes',
       classpara:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum issss has been the industrys standard dummy text ever since the 1500s, when an unknown lorem',
       classtext1:'Yoga For Climbers',
       classbutton:'View All Classes',
       classschedule:'Class Schedule',
       time:'Time',
       saturday:'Saturday',
       sunday:'Sunday',
       monday:'Monday',
       tuesday:'Tuesday',
       wednesday:'Wednesday',
       thrusday:'Thrusday',
       friday:'Friday',
       time1:'8:00 AM',
       time2:'12:00 AM',
       time3:'3:00 PM',
       time4:'6:00 PM',
       c1text1:'yoga for climbers',
       c1text2:'Sathi Bhuiyan',
       c1text2:'8.00 Am-10.00Am',
      // class schedule end
       trainerhead:'Our Trainer',
       trainerimg1:'./public/image/illustration/trainer1.webp',
       trainerimg2:'./public/image/illustration/trainer2.webp',
       trainerimg3:'./public/image/illustration/trainer3.webp',
      //  Trainer end
      galleryhead:'Our Gallery',
      galleryimg1:'./public/image/illustration/gal (1).webp',
      galleryimg2:'./public/image/illustration/gal2.webp',
      galleryimg3:'./public/image/illustration/gal3.webp',
      galleryimg4:'./public/image/illustration/gal4.webp',
      galleryimg5:'./public/image/illustration/gal5.webp',
      galleryimg6:'./public/image/illustration/gal6.webp',
      // Gallery end
      awesomehead:'Awesome Event',
      awesomechaildhead:'Yoga celebration in Handstand',
      awesometext:'25 March 2021',
      awesometext2:'10AM - 12AM',
      // Awesome end
      Bloghead:'Our Blog',
      blogimg1:'./public/image/illustration/blog1.webp',
      blogtext:'Curabitur ante justo,  vitae.',
      blogtext2:'25 March 2021',
      blogtext3:'Read More',
      blogimg2:'./public/image/illustration/blog2.webp',
      // Blog end
      Pricingthead:'Pricing Table',
      pricingtext:'SILVER PACKAGE',
      pricingtext6:'GOLD PACKAGE',
      pricingtext7:'PLATINUM PACKAGE',
      pricingtext2:'Free T-Shirt & swags',
      pricingtext3:'Free of all message treatments',
      pricingtext4:' Access Clup Facilites',
      pricingtext5:'Out Door activites',
      // pricing end
      Clienthead:'Our Client Say',
      clientpara:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla non mi just. Aliquam vitae purus vel odio suscipit lobortis. Donec interdum finibus egestas. In eleifend ipsum eu lacinia congue. Vestibulum sodales, sapien aliquam ',
      Clientsign:'./public/image/icons/signature.webp',
      clienttext:'Co-Founder Of Company',
      // Client end
      footerimg:'./public/image/icons/logo.webp',
      footertext:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a convallis nulla. Ut',
      a1:'username@gmail.com',
      a2:' (+660 256 24857)',
      a3:' Your Address Here',
      footerpara:'@envato good News for today!! We got 2 psd templete weekly top selling quality template in technology category !!!',
      link:'https://twitter.com/login',
      footerhead:'RECENT TWEETS',
      footerhead2:'GET IN TUCH',
    }
  ]

  // #_____________ Home section end_____________ #
  
  const Aboutt=[
    { sym:'>',
      Ahead:'ABOUT US',
     abouthead:'About Our Handstand',
     classpara:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum issss has been the industrys standard dummy text ever since the 1500s, when an unknown lorem',
     classtext1:'Yoga For Climbers',
     aboutpara:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum issss has been the industrys standard dummy text ever since the 1500s, when an unknown lorem printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, lorem ipsum is but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and is more recently with desktop publishing software like Aldus PageMaker including versions.',
   // about end
     Clienthead:'Our Client Say',
     clientpara:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla non mi just. Aliquam vitae purus vel odio suscipit lobortis. Donec interdum finibus egestas. In eleifend ipsum eu lacinia congue. Vestibulum sodales, sapien aliquam ',
     Clientsign:'./public/image/icons/signature.webp',
     clienttext:'Co-Founder Of Company',
  // Client end
     awesomehead:'Awesome Event',
     awesomechaildhead:'Yoga celebration in Handstand',
     awesometext:'25 March 2021',
     awesometext2:'10AM - 12AM',
  // Awesome end
     footerimg:'./public/image/icons/logo.webp',
     footertext:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a convallis nulla. Ut',
     a1:'username@gmail.com',
     a2:' (+660 256 24857)',
     a3:' Your Address Here',
     footerpara:'@envato good News for today!! We got 2 psd templete weekly top selling quality template in technology category !!!',
     link:'https://twitter.com/login',
     footerhead:'RECENT TWEETS',
     footerhead2:'GET IN TUCH',

    }
  ]

// #_____________About section end_____________ #

  const classinfo=[
    {
     chead:'CLASS',
     sym:'>',
     classhead:'Our Classes',
     classpara:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum issss has been the industrys standard dummy text ever since the 1500s, when an unknown lorem',
     classtext1:'Yoga For Climbers',
     classbutton:'View All Classes',
     classschedule:'Class Schedule',
     time:'Time',
     saturday:'Saturday',
     sunday:'Sunday',
     monday:'Monday',
     tuesday:'Tuesday',
     wednesday:'Wednesday',
     thrusday:'Thrusday',
     friday:'Friday',
     time1:'8:00 AM',
     time2:'12:00 AM',
     time3:'3:00 PM',
     time4:'6:00 PM',
     c1text1:'yoga for climbers',
     c1text2:'Sathi Bhuiyan',
     c1text2:'8.00 Am-10.00Am',
     trainerhead:'Our Trainer',
     trainerimg1:'./public/image/illustration/trainer1.webp',
     trainerimg2:'./public/image/illustration/trainer2.webp',
     trainerimg3:'./public/image/illustration/trainer3.webp',
   // classes end
     Pricingthead:'Pricing Table',
     pricingtext:'SILVER PACKAGE',
     pricingtext6:'GOLD PACKAGE',
     pricingtext7:'PLATINUM PACKAGE',
     pricingtext2:'Free T-Shirt & swags',
     pricingtext3:'Free of all message treatments',
     pricingtext4:' Access Clup Facilites',
     pricingtext5:'Out Door activites',
   // pricing end
     Clienthead:'Our Client Say',
     clientpara:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla non mi just. Aliquam vitae purus vel odio suscipit lobortis. Donec interdum finibus egestas. In eleifend ipsum eu lacinia congue. Vestibulum sodales, sapien aliquam ',
     Clientsign:'./public/image/icons/signature.webp',
     clienttext:'Co-Founder Of Company',
    // Client end
     footerimg:'./public/image/icons/logo.webp',
     footertext:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a convallis nulla. Ut',
     a1:'username@gmail.com',
     a2:' (+660 256 24857)',
     a3:' Your Address Here',
     footerpara:'@envato good News for today!! We got 2 psd templete weekly top selling quality template in technology category !!!',
     link:'https://twitter.com/login',
     footerhead:'RECENT TWEETS',
     footerhead2:'GET IN TUCH',

    }
  ]
 // #_____________ Class section end_____________ #

 const Gallery=[
  {
   Ghead:'GALLERY', 
   sym:'>',
   classpara:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum issss has been the industrys standard dummy text ever since the 1500s, when an unknown lorem',
   Clienthead:'Our Client Say',
   clientpara:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla non mi just. Aliquam vitae purus vel odio suscipit lobortis. Donec interdum finibus egestas. In eleifend ipsum eu lacinia congue. Vestibulum sodales, sapien aliquam ',
   Clientsign:'./public/image/icons/signature.webp',
   clienttext:'Co-Founder Of Company',
 //  client end
   galleryhead:'Our Gallery',
   galleryimg1:'./public/image/illustration/gal (1).webp',
   galleryimg2:'./public/image/illustration/gal2.webp',
   galleryimg3:'./public/image/illustration/gal3.webp',
   galleryimg4:'./public/image/illustration/gal4.webp',
   galleryimg5:'./public/image/illustration/gal5.webp',
   galleryimg6:'./public/image/illustration/gal6.webp',
 // Gallery end
   footerimg:'./public/image/icons/logo.webp',
   footertext:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a convallis nulla. Ut',
   a1:'username@gmail.com',
   a2:' (+660 256 24857)',
   a3:' Your Address Here',
   footerpara:'@envato good News for today!! We got 2 psd templete weekly top selling quality template in technology category !!!',
   link:'https://twitter.com/login',
   footerhead:'RECENT TWEETS',
   footerhead2:'GET IN TUCH',
}
]
// #_____________ Gallery section end_____________ #

  const Blog1=[
    {
     Bhead:'BLOG',
     sym:'>',
     classpara:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum issss has been the industrys standard dummy text ever since the 1500s, when an unknown lorem',
     Clienthead:'Our Client Say',
     clientpara:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla non mi just. Aliquam vitae purus vel odio suscipit lobortis. Donec interdum finibus egestas. In eleifend ipsum eu lacinia congue. Vestibulum sodales, sapien aliquam ',
     Clientsign:'./public/image/icons/signature.webp',
     clienttext:'Co-Founder Of Company',
   //  client end
     Bloghead:'Our Blog',
     blogimg1:'./public/image/illustration/blog1.webp',
     blogtext:'Curabitur ante justo,  vitae.',
     blogtext2:'25 March 2021',
     blogtext3:'Read More',
     blogimg2:'./public/image/illustration/blog2.webp',
   // blog end
     footerimg:'./public/image/icons/logo.webp',
     footertext:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a convallis nulla. Ut',
     a1:'username@gmail.com',
     a2:' (+660 256 24857)',
     a3:' Your Address Here',
     footerpara:'@envato good News for today!! We got 2 psd templete weekly top selling quality template in technology category !!!',
     link:'https://twitter.com/login',
     footerhead:'RECENT TWEETS',
     footerhead2:'GET IN TUCH',

   }
 ]
 // #_____________ Blog section end_____________ #

  const contact=[
    {
     Cohead:'CONTACT',
     sym:'>',
     Clienthead:'Our Client Say',
     clientpara:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla non mi just. Aliquam vitae purus vel odio suscipit lobortis. Donec interdum finibus egestas. In eleifend ipsum eu lacinia congue. Vestibulum sodales, sapien aliquam ',
     Clientsign:'./public/image/icons/signature.webp',
     clienttext:'Co-Founder Of Company',
    //  client end
     footerimg:'./public/image/icons/logo.webp',
     footertext:'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a convallis nulla. Ut',
     a1:'username@gmail.com',
     a2:' (+660 256 24857)',
     a3:' Your Address Here',
     footerpara:'@envato good News for today!! We got 2 psd templete weekly top selling quality template in technology category !!!',
     link:'https://twitter.com/login',
     footerhead:'RECENT TWEETS',
     footerhead2:'GET IN TUCH',
     footerhead3:'Contact Form',
    }
  ]

  return (
     <>
        <BrowserRouter>
        
           <Navigation/>

               <Routes>
                    {/* <Route path="/" element={<Home/>}/> */}
                    <Route path="/" element={<Home Hom={Homm}/>}/>
                    <Route path="About" element={<About Abut={Aboutt}/>}/>
                    <Route path="Classes" element={<Classes clss={classinfo}/>}/>
                    <Route path="Gallery" element={<Galleryy galry={Gallery}/>}/>
                    <Route path="Blog" element={<Blog blogs={Blog1}/>}/>
                    <Route path="Contact" element={<Contact cont={contact}/>}/>
               </Routes>

        </BrowserRouter>
          
    </>
  )
}

export default App
