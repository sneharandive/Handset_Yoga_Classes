
const Blog=(props)=>
    {
      const blogg=props.blogs 
      {
       return(
        blogg.map((x)=>
            {
            return(
                <>
                <section>
                               <div className="aboutbg">
    
                                  <div className='lists  mx-auto w-75'>
                                            <h2 className=' text-light' ><b>{x.Bhead}</b></h2>
                                     <ul className='d-flex '>
                                          <li><a className='text-decoration-none text-light'  href="Home.jsx"><b>HOME</b> <span>{x.sym}</span></a></li>
                                          <li><a className='text-decoration-none text-light' href=""> <b> BLOG</b></a></li>
                                     </ul>
                                  </div>
                                 
                               </div>
                       </section>

            {/* ############## Hero section end ############## */} 

                <section className='Blog w-100'>
                                          <div className='container'>
                                                       <div className='p-2 w-75 mx-auto'>
                                                                <h1 className='text-secondary text-center pt-4'><b>{x.Bloghead}</b></h1>
                                                                <p className='text-secondary text-center'>{x.classpara}</p>
                                                       </div>
         
                                                       <div className='container mx-auto'>
                                                              <div className='row shadow bg-light mt-4'>
                                                                  <div className='col-md-4'>
                                                                          <img src={x.blogimg1} alt="" srcset="" width="100%" height="300px" />
                                                                  </div>
                                                                  <div className='blogdiv col-md-8 shadow  mt-3 p-3'>
                                                                            <a href="" className='text-secondary text-decoration-none'>{x.blogtext}</a>
                                                                            <h6 className='text-secondary mt-2'>{x.blogtext2}</h6>
                                                                            <p className='fs-6 text-secondary'>{x.classpara}</p>
                                                                            <a href="" className='text-secondary text-decoration-none'>{x.blogtext3}</a>
                                                                  </div>
                                                                  <div className='col-md-4 mt-3'>
                                                                          <img src={x.blogimg2} alt="" srcset="" width="100%" height="300px"/>
                                                                  </div>
                                                                  <div className='blogdiv col-md-8 mx-auto shadow mt-3 p-3'>
                                                                            <a href="" className='text-secondary text-decoration-none'>{x.blogtext}</a>
                                                                            <h6 className='text-secondary mt-2'>{x.blogtext2}</h6>
                                                                            <p className='fs-6 text-secondary'>{x.classpara}</p>
                                                                            <a href="" className='text-secondary text-decoration-none'>{x.blogtext3}</a>
                                                                  </div>
                                                              </div>
                                                       </div>
                                          </div>    
                                  </section>  

      {/* ############## blog section end ############## */} 

                                 <section className='Client w-100'>

                                                 <div className='p-2 w-75 mx-auto'>
                                                         <h1 className='text-secondary text-center pt-4'><b>{x.Clienthead}</b></h1>
                                                         <p className='text-secondary text-center'>{x.classpara}</p>
                                                 </div>
                         
                                                 <div className='shadow bg-info mt-4 m-4 text-light text-center mb-3'>
                                                                                 
                                                         <p className='p-1'>{x.clientpara}</p>
                                                         <img src={x.Clientsign} alt="" />
                                                         <h6 className='pt-3 p-3'>{x.clienttext}</h6>
                                                                                       
                                                 </div>
                                                                    
                                </section>    
                                                  
       {/* ############## Client section end ############## */} 
                
                       <section className='Footer w-100'>

                                          <div className='container' >

                                              <div className='row w-100 mt-5'>
    
                                                       <div className='col-md-6 col-lg-4'>

                                                                 <img src={x.footerimg} alt="" srcset="" width={80} height={60} className='mt-2'/>
                                                                
                                                                 <p className='mt-3'>{x.footertext}</p>
                                                                    <ul>
                                                                             <li  className='mt-2'>
                                                                                <a href=""></a><i class="bi bi-envelope-fill"></i> {x.a1}
                                                                            </li>
    
                                                                             <li className='mt-2'>
                                                                                  <a href=""></a><i class="bi bi-telephone-fill"></i> {x.a2}
                                                                             </li>
    
                                                                             <li className='mt-2'>
                                                                                  <a href=""></a><i class="bi bi-house-door-fill"></i> {x.a3}
                                                                             </li>
                                                                    </ul>
                                                        </div>
                                                    
                                                        <div className='col-md-6 col-lg-4'>

                                                                <h3  className='mt-3'><b>{x.footerhead}</b></h3>
    
                                                                 <p><i class="bi bi-twitter"></i> {x.footerpara}</p>
                                                                 <a href="" className=''>{x.link}</a>
                                                                
                                                                 <p className='pt-3'><i class="bi bi-twitter"></i> {x.footerpara}</p>
                                                                 <a href="">{x.link}</a>
                                                        </div>
    
                                                        <div className='col-md-6 col-lg-4'>

                                                                 <h3  className='mt-3'><b>{x.footerhead2}</b></h3>
                                                                       <form>
                                                                            <div className='d-md-flex'>
                                                                                  <div><input type="text" placeholder='Name'className='inputbox p-1' /></div><br></br>
                                                                                  <div><input type="email" placeholder='Email' className='inputbox p-1'/></div>
                                                                            </div>
                                                                            <input type="text" placeholder='Subject' className=' subj mt-3' /><br></br>
         
                                                                            <button type='submit' className='bg-info submit text-light text-center border border-none mt-3'>Submit</button>
                                                                       </form>
                                                        </div>
                                                          
                                                    </div>
                                                   
                                       </div>
                        </section>
                                           
                </>
            )
          })
        )
      }
    }
export default Blog