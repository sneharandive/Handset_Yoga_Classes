import './about.css'
const About=(props)=>
    {
        const self=props.Abut
        {
         return(
            self.map((x)=>
              {
              return(

                  <>
                       <section>
                               <div className="aboutbg">
                                 
                                     <div className='lists mx-auto w-75'>
                                               <h2 className=' text-light' ><b>{x.Ahead}</b></h2>
                                               <ul className='d-flex '>
                                                     <li><a className='text-decoration-none text-light'  href="Home.jsx"><b>HOME</b> <span>{x.sym}</span></a></li>
                                                     <li><a className='text-decoration-none text-light' href=""> <b> ABOUT US</b></a></li>
                                               </ul>
                                     </div>
                                 
                               </div>
                       </section>

      {/* ############## Hero section end ############## */} 
                 
                  <section className='w-100 mt-4'>
                                         
                            <div className='container '>
                                               <div className='row about mx-auto'>

                                                        <div className='col-lg-6'>

                                                               <h2 className='mt-3'><b>{x.abouthead}</b></h2>  
                                                               <p>{x.aboutpara}</p> 
                                                               <button type="button" className="btn rounded-pill border-info mt-3 mb-5" >Read More</button> 
                                      
                                                        </div>
                  
                                                        <div className='col-lg-6 div1 mx-auto shadow'>

                                                              <div className='bg-2 m-2'>
                                                                  <div className='play  mx-auto'><i class="bi bi-play-fill fs-1  text-light"></i></div>
                                                              </div>

                                                        </div>
                                               </div>
                             </div>
                  
                 </section>
                           
 {/* ############## About section end ############## */} 
                  
                 <section className='Classes w-100 mx-auto'>
                                       
                            <div className='p-2 w-75 mx-auto'>

                                         <h1 className='text-secondary text-center pt-4'><b>{x.awesomehead}</b></h1>
                                         <p className='text-secondary text-center'>{x.classpara}</p>
                            </div>
         
                                                      
                             <div className='awesome1 mx-auto shadow-lg bg-light mt-3 m-4'>

                                        <div className='awesome shadow text-center mx-auto bg-light'>

                                              <h3 className='pt-3'>{x.awesomechaildhead}</h3>
                                              <p className='p-1'>{x.classpara}</p>
                                              <h4 className='text-info'>{x.awesometext}</h4>
                                              <h5 className='pt-1 mb-3'>{x.awesometext2}</h5>

                                        </div>

                            </div>
                                                       
                 </section>    

 {/* ############## Awesome section end ############## */}         

                 <section className='Footer w-100'>

                            <div className='container' >

                                    <div className='row w-100 mt-5'>
          
                                           <div className='col-md-6 col-lg-4'>
                                                        <img src={x.footerimg} alt="" srcset="" width={80} height={60} className='mt-2'/>
                                                        <p className='mt-3'>{x.footertext}</p>

                                                        <ul>
                                                                    <li  className='mt-2'>
                                                                       <a href=""></a><i class="bi bi-envelope-fill"></i> {x.a1}
                                                                   </li>
                                                                    <li className='mt-2'>
                                                                         <a href=""></a><i class="bi bi-telephone-fill"></i> {x.a2}
                                                                    </li>
                                                                    <li className='mt-2'>
                                                                         <a href=""></a><i class="bi bi-house-door-fill"></i> {x.a3}
                                                                    </li>
                                                        </ul>
                                            </div>
                                                          
                                            <div className='col-md-6 col-lg-4'>

                                                         <h3  className='mt-3'><b>{x.footerhead}</b></h3>
          
                                                         <p><i class="bi bi-twitter"></i> {x.footerpara}</p>
                                                         <a href="" className=''>{x.link}</a>
                                                                      
                                                         <p className='pt-3'><i class="bi bi-twitter"></i> {x.footerpara}</p>
                                                         <a href="">{x.link}</a>

                                            </div>
          
                                             <div className='col-md-6 col-lg-4'>

                                                         <h3  className='mt-3'><b>{x.footerhead2}</b></h3>

                                                             <form>
                                                                    <div className='d-md-flex'>

                                                                               <div><input type="text" placeholder='Name'className='inputbox p-1' /></div><br></br>
                                                                                <div><input type="email" placeholder='Email' className='inputbox p-1'/></div>
                                                                    </div>
                                                                             <input type="text" placeholder='Subject' className=' subj mt-3' /><br></br>
          
                                                                             <button type='submit' className='bg-info submit text-light text-center border border-none mt-3'>Submit</button>
                                                             </form>
                                            </div>
                                                                
                                     </div>
                                                          
                                </div>
                                               
                        </section>
                                                              
                  </>
              )
          })
         )
        }
         
      }

 export default About