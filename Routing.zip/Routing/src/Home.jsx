import './Style.css'
const Home=(props)=>
{
      const hom=props.Hom;
           
      return(
            <>
               {
                  hom.map((x)=>
                  {
                        return(
                              <>
                                <section className='w-100' >
                                            <div id="carouselExampleIndicators" class="carousel slide text">
                                                    <div class="carousel-indicators">
                                                          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                                          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                                          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                                                    </div>
                  
                                                    <div className="bg-1">
                            
                                                          <div className='bgtext mx-auto text-align-center text-secondary '>
                                                                     <p className='head pt-4'>{x.one}</p>
                                                                     <h1 className="head mx-auto fw-1" ><b>Keep <span className='text-info'>Refresh & Strong</span> Your Body</b></h1>
                                                                     <p className='text1 mt-3'>{x.text}</p>
                                                                     <button type="button" className="btn button rounded-pill border-info mt-3 mb-5" >Read More</button>
                                                          </div>

                                                    </div>
                                        </div>
                                 </section>
                  
{/*# Home section end #*/}
                  
                                 <section className='w-100 mt-4'>
                                         
                                         <div className='container'>
                                                 <div className='row about mx-auto'>

                                                            <div className='col-lg-6'>
  
                                                                   <h2 className='mt-3'><b>{x.abouthead}</b></h2>  
                                                                   <p>{x.aboutpara}</p> 
                                                                   <button type="button" className="btn rounded-pill border-info mt-3 mb-5" >Read More</button> 
                                          
                                                            </div>
                      
                                                            <div className='col-lg-6 div1 mx-auto shadow'>
  
                                                                  <div className='bg-2 m-2'>
                                                                      <div className='play  mx-auto'><i class="bi bi-play-fill fs-1  text-light"></i></div>
                                                                  </div>
                                                                  
                                                            </div>
                                                 </div>
                                         </div>
                  
                                 </section>
                  
{/* # About section end # */}
                  
                                <section className='Classes w-100'>
                                              <div className="w-75 mx-auto">
                                                       <h1 className='text-secondary text-center pt-4'><b>{x.classhead}</b></h1>
                                                       <p className='text-secondary text-center'>{x.classpara}</p>
                                              </div>

                                               <div className='container mt-5'>
                                                         <div className='row'>
                                                               
                                                                 <div className='col-md-6  col-lg-4'>
                                                                     
                                                                        <div className='classimg1'></div>
                                                                              <div className=' bg-light text-secondary text-center pt-2'>
                                                                                     <h5>{x.classtext1}</h5>
                                                                                     <hr className='text-secondary' />
                                                                                     <p><i class="bi bi-emoji-smile  text-info"></i> Sathi Bhuiyan</p>
                                                                                     <p className='mb-3 p-3'><i class="bi bi-alarm text-info"></i> 10.00Am-05:00Pm</p>
                                                                              </div>
                                                                 </div>
                                                               
                                                               <div className='col-md-6  col-lg-4'>
                                                                     
                                                                       <div className='classimg2'></div>
                                                                                <div className='bg-light text-secondary text-center pt-2'>
                                                                                     <h5>{x.classtext1}</h5>
                                                                                     <hr className='text-secondary'/>
                                                                                     <p><i class="bi bi-emoji-smile  text-info"></i> Sathi Bhuiyan</p>
                                                                                     <p className='mb-3 p-3'><i class="bi bi-alarm text-info"></i> 10.00Am-05:00Pm</p>
                                                                                 </div>
                                                               
                                                               </div>
                                                               
                                                               <div className='col-md-6  col-lg-4'>
                                                                      
                                                                      <div className='classimg3'></div>
                                                                             <div className='bg-light text-secondary text-center pt-2'>
                                                                                 <h5>{x.classtext1}</h5>
                                                                                 <hr className='text-secondary'/>
                                                                                 <p><i class="bi bi-emoji-smile  text-info"></i> Sathi Bhuiyan</p>
                                                                                 <p className='mb-3 p-3'><i class="bi bi-alarm text-info"></i> 10.00Am-05:00Pm</p>
                                                                             </div>
                                                               
                                                               </div>
                                                               
                                                                <div className='classbtn mx-auto text-center'>
                                                                     <button type="button" className="btn btn-center rounded-pill border-info mt-3 mb-5" >{x.classbutton}</button>   
                                                               </div>

                                                         </div>
                                                </div>

     {/* # Classes section end # */}
                          
                         <section className='CLASS Schedule'>      
                                    <div className="w-75 mx-auto">
                                             <h1 className='text-secondary text-center pt-4'><b>{x.classschedule}</b></h1>
                                             <p className='text-secondary text-center'>{x.classpara}</p>
                                     </div>

                                     <div class="scehedule-table table-content table-responsive text-center">
                                              <table className='table table-bordered  text-center  w-75 mx-auto'>
                                                    <thead className='table table-secondary'>
                                                           <tr>
                                                                 <th>{x.time}</th>
                                                                 <th>{x.saturday}</th>
                                                                 <th>{x.sunday}</th>
                                                                 <th>{x.monday}</th>
                                                                 <th>{x.tuesday}</th>
                                                                 <th>{x.wednesday}</th>
                                                                 <th>{x.thrusday}</th>
                                                                 <th>{x.friday}</th>
                                                           </tr>
                                                    </thead>

                                                        <tbody class=" table- pt-30 ">
                                                                <tr>
                                                                        <td class="text-secondary pt-5">
                                                                           <p>{x.time1}</p>
                                                                        </td>
   
                                                                       <td className="table-warning">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
   
                                                                       <td></td>
                                                                       <td></td>
   
                                                                       <td class="table-warning">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
   
                                                                       <td></td>
   
                                                                       <td class="table-warning">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
   
                                                                       <td></td>

                                                                </tr>

                                                                 <tr>
                                                                       <td class="text-secondary pt-5">
                                                                           <p>{x.time2}</p>
                                                                       </td>
  
                                                                       <td></td>
                                                                       <td></td>
  
                                                                       <td class="table-info">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
  
                                                                       <td></td>
  
                                                                       <td class="table-info">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
  
                                                                       <td></td>
                                                                       <td></td>
                                                                       
                                                                 </tr>

                                                                 <tr>
                                                                       <td class="text-secondary pt-5">
                                                                           <p>{x.time3}</p>
                                                                       </td>
  
                                                                       <td></td>
  
                                                                       <td class="table-primary">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
  
                                                                       <td></td>
                                                                       <td></td>
  
                                                                       <td class="table-primary">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
  
                                                                       <td></td>
  
                                                                       <td class="table-primary">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>

                                                                 </tr>

                                                                 <tr>
                                                                       <td class="text-secondary pt-5">
                                                                           <p>{x.time4}</p>
                                                                       </td>

                                                                       <td class="table-danger ">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>
                                                                       
                                                                       <td></td>
                                                                       <td></td>

                                                                       <td class="table-danger">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>

                                                                       <td></td>

                                                                       <td class="table-danger">
                                                                           <p>{x. c1text1}</p>
                                                                           <p>{x. c1text2}</p>
                                                                           <p>{x. c1text3}</p>
                                                                       </td>

                                                                       <td></td>
                                                                 </tr>

                                                         </tbody>
                                             </table>
                        </div>
                        {/* </div> */}
                  
                          </section>
  
     {/* # Table Classes section end # */}

                                    <div className='container mt-5 w-100'>
                                              <div className='p-2 w-75 mx-auto'>
                                                       <h1 className='text-secondary text-center pt-4'><b>{x.trainerhead}</b></h1>
                                                       <p className='text-secondary text-center'>{x.classpara}</p>
                                              </div>

                                                <div className='row'>
                                                           
                                                        <div className='col-md-6  col-lg-4'>
                                                                   <img src={x.trainerimg1} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                           </div>
                                                           
                                                           <div className='col-md-6  col-lg-4'>
                                                                   <img src={x.trainerimg2} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                           </div>
                                                           
                                                           <div className='col-md-6  col-lg-4'>
                                                                  <img src={x.trainerimg3} alt="" srcset="" width="100%" height={250} className='mt-3 mb-4'/>
                                                           </div>
                                                      </div>
                                                </div>
                                   </section>

  {/* # Trainer section end # */}

                                   <section className='Gallery w-100'> 
                                            <div className='container'>
                                                    <div className="w-75 mx-auto">
                                                              <h1 className='text-secondary text-center pt-4'><b>{x.galleryhead}</b></h1>
                                                              <p className='text-secondary text-center'>{x.classpara}</p>
                                                     </div>

                                                     <div className='container mt-5'>
                                                            <div className='row'>
                                                           
                                                                    <div className='col-md-4 '>
                                                                            <img src={x.galleryimg1} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                                    </div>
                                                                    
                                                                    <div className='col-md-4 '>
                                                                            <img src={x.galleryimg2} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                                    
                                                                    </div>
                                                                    
                                                                    <div className='col-md-4 '>
                                                                           <img src={x.galleryimg3} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                                    </div>
                                                                    
                                                                    <div className='col-md-4'>
                                                                            <img src={x.galleryimg4} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                                    </div>
                                                                    
                                                                    <div className='col-md-4 '>
                                                                            <img src={x.galleryimg5} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                                    
                                                                    </div>
                                                                    
                                                                    <div className='col-md-4 '>
                                                                           <img src={x.galleryimg6} alt="" srcset="" width="100%" height={250} className='mt-3'/>
                                                                    </div>
      
                                                            </div>
                                                    </div>
                                          </div>

                                   </section>

      {/* # Gallery section end # */}   

                                  <section className='Classes w-100 mx-auto'>
                                         
                                            <div className='p-2 w-75 mx-auto'>
                                                        <h1 className='text-secondary text-center pt-4'><b>{x.awesomehead}</b></h1>
                                                        <p className='text-secondary text-center'>{x.classpara}</p>
                                             </div>
             
                                                          
                                            <div className='awesome1 mx-auto shadow-lg bg-light mt-3 m-4'>
                                                        <div className='awesome shadow text-center mx-auto bg-light  '>
                                                                <h3 className='pt-3'>{x.awesomechaildhead}</h3>
                                                                <p className='p-1'>{x.classpara}</p>
                                                                <h4 className='text-info'>{x.awesometext}</h4>
                                                                <h5 className='pt-1 mb-3'>{x.awesometext2}</h5>
                                                        </div>
                                            </div>
                                                    
                                  </section>     
                              
     {/* # Awesome section end # */}  

                                  <section className='Blog w-100'>
                                          <div className='container'>
                                                       <div className='p-2 w-75 mx-auto'>
                                                                <h1 className='text-secondary text-center pt-4'><b>{x.Bloghead}</b></h1>
                                                                <p className='text-secondary text-center'>{x.classpara}</p>
                                                       </div>
         
                                                       <div className='container mx-auto'>
                                                              <div className='row shadow bg-light mt-4'>
                                                                         <div className='col-md-4'>
                                                                                <img src={x.blogimg1} alt="" srcset="" width="100%" height="300px" />
                                                                         </div>

                                                                         <div className='blogdiv col-md-8 shadow  mt-3 p-3'>
                                                                                   <a href="" className='text-secondary text-decoration-none'>{x.blogtext}</a>
                                                                                   <h6 className='text-secondary mt-2'>{x.blogtext2}</h6>
                                                                                   <p className='fs-6 text-secondary'>{x.classpara}</p>
                                                                                   <a href="" className='text-secondary text-decoration-none'>{x.blogtext3}</a>
                                                                         </div>

                                                                         <div className='col-md-4 mt-3'>
                                                                                 <img src={x.blogimg2} alt="" srcset="" width="100%" height="300px"/>
                                                                         </div>

                                                                         <div className='blogdiv col-md-8 mx-auto shadow mt-3 p-3'>
                                                                                   <a href="" className='text-secondary text-decoration-none'>{x.blogtext}</a>
                                                                                   <h6 className='text-secondary mt-2'>{x.blogtext2}</h6>
                                                                                   <p className='fs-6 text-secondary'>{x.classpara}</p>
                                                                                   <a href="" className='text-secondary text-decoration-none'>{x.blogtext3}</a>
                                                                         </div>
                                                                </div>
                                                        </div>
                                          </div> 

                                  </section>  

     {/* # Blog section end # */}  
              
                                   <section className='Classes w-100 mxauto'>
                                          <div className='container'>
                                                       <div className='p-2 w-75 mx-auto'>
                                                                <h1 className='text-secondary text-center pt-4'><b>{x.Pricingthead}</b></h1>
                                                                <p className='text-secondary text-center'>{x.classpara}</p>
                                                       </div>
         
                                                       <div className='row p-4'>
                                                                      <div className='pricebox col-md-6  col-lg-4 shadow text-secondary mt-3 text-center mb-2'>
        
                                                                                 <div>
                                                                                      <h3 className='pt-2 prictext text-center '>{x.pricingtext}</h3>
                                                                                      <h1 className='price bg-light pt-3'>$30<span className='fs-3'>/month</span></h1>
                                                                                      <p className='pt-3 '>{x.pricingtext2}</p>
                                                                                      <hr />
                                                                                      <p className='pt-3 '>{x.pricingtext3}</p>
                                                                                      <hr />
                                                                                      <p className='pt-3 '>{x.pricingtext4}</p>
                                                                                      <hr />
                                                                                      <p className='pt-4 mb-2 text-center p-3'>{x.pricingtext5}</p>
                                                                                 </div>
             
                                                                                  <div className='pricebtn text center '>   
                                                                                      <button type="button" className="btn btn-center shadow-lg rounded-pill text-info shadow mt-4 mb-5" >{x.classbutton}</button>   
                                                                                  </div>
        
                                                                      </div>
                                                            
                                                                     <div className='pricebox col-md-6  col-lg-4 shadow mx-auto  text-secondary mt-3 text-center mb-2'>
        
                                                                                  <div>
                                                                                       <h3 className='pt-2 prictext text-center '>{x.pricingtext6}</h3>
                                                                                       <h1 className='price bg-light pt-3'>$50<span className='fs-3'>/month</span></h1>
                                                                                       <p className='pt-3 '>{x.pricingtext2}</p>
                                                                                       <hr />
                                                                                       <p className='pt-3 '>{x.pricingtext3}</p>
                                                                                       <hr />
                                                                                       <p className='pt-3 '>{x.pricingtext4}</p>
                                                                                       <hr />
                                                                                       <p className='pt-4 text-center p-3'>{x.pricingtext5}</p>
                                                                                  </div>
                
                                                                                  <div className='pricebtn text center '> 
                                                                                           <button type="button" className="btn btn-center shadow-lg rounded-pill text-info shadow mt-3 mb-5" >{x.classbutton}</button>   
                                                                                  </div>
        
                                                                      </div>
                                                                       
                                                                     <div className='pricebox col-md-6  col-lg-4 shadow text-secondary mt-3 text-center mb-2'>
        
                                                                                  <div>
                                                                                       <h3 className='pt-2 prictext text-center '>{x.pricingtext7}</h3>
                                                                                       <h1 className='price bg-light pt-3'>$70<span className='fs-3'>/month</span></h1>
                                                                                       <p className='pt-3 '>{x.pricingtext2}</p>
                                                                                       <hr />
                                                                                       <p className='pt-3 '>{x.pricingtext3}</p>
                                                                                       <hr />
                                                                                       <p className='pt-3 '>{x.pricingtext4}</p>
                                                                                       <hr />
                                                                                       <p className='pt-4 mb-2 text-center p-3'>{x.pricingtext5}</p>
                                                                                  </div>
            
                                                                                  <div className='pricebtn text center '> 
                                                                                           <button type="button" className="btn btn-center shadow-lg rounded-pill text-info shadow mt-3 mb-5" >{x.classbutton}</button>   
                                                                                 </div>
                                                                      </div>
                                                                
                                                       </div>
                                          </div>   

                                  </section> 

       {/* # pricing section end # */}     

                                    
                                 <section className='Client w-100'>
                                         
                                                       <div className='p-2 w-75 mx-auto'>
                                                                <h1 className='text-secondary text-center pt-4'><b>{x.Clienthead}</b></h1>
                                                                <p className='text-secondary text-center'>{x.classpara}</p>
                                                       </div>
         
                                                    
                                                       <div className='shadow bg-info mt-4 m-4 text-light text-center mb-3'>
                                                                        <p className='p-1'>{x.clientpara}</p>
                                                                        <img src={x.Clientsign} alt="" />
                                                                        <h6 className='pt-3 p-3'>{x.clienttext}</h6>
                                                        </div>
                                                      
                                  </section>    
                                  
       {/* # Client section end # */} 

                                 <section className='Footer w-100'>

                                         <div className='container' >

                                               <div className='row w-100 mt-5'>

                                                            <div className='col-md-6 col-lg-4'>
         
                                                                      <img src={x.footerimg} alt="" srcset="" width={80} height={60} className='mt-2'/>
                                                                      <p className='mt-3'>{x.footertext}</p>
                                                                                  <ul>
                                                                                           <li  className='mt-2'>
                                                                                              <a href=""></a><i class="bi bi-envelope-fill"></i> {x.a1}
                                                                                          </li>
                  
                                                                                           <li className='mt-2'>
                                                                                                <a href=""></a><i class="bi bi-telephone-fill"></i> {x.a2}
                                                                                           </li>
                  
                                                                                           <li className='mt-2'>
                                                                                                <a href=""></a><i class="bi bi-house-door-fill"></i> {x.a3}
                                                                                           </li>
                                                                                  </ul>
                                                             </div>
                                                         
                                                             <div className='col-md-6 col-lg-4'>
         
                                                                     <h3  className='mt-3'><b>{x.footerhead}</b></h3>
         
                                                                      <p><i class="bi bi-twitter"></i> {x.footerpara}</p>
                                                                      <a href="" className=''>{x.link}</a>
                                                                     
                                                                      <p className='pt-3'><i class="bi bi-twitter"></i> {x.footerpara}</p>
                                                                      <a href="">{x.link}</a>
                                                             </div>
         
                                                             <div className='col-md-6 col-lg-4'>
         
                                                                      <h3  className='mt-3'><b>{x.footerhead2}</b></h3>
                                                                              <form>
                                                                                         <div className='d-md-flex'>
                
                                                                                               <div><input type="text" placeholder='Name'className='inputbox p-1' /></div><br></br>
                                                                                               <div><input type="email" placeholder='Email' className='inputbox p-1'/></div>
                                                                                         
                                                                                         </div>
                                                                                         
                                                                                         <input type="text" placeholder='Subject' className=' subj mt-3' /><br></br>
                      
                                                                                         <button type='submit' className='bg-info submit text-light text-center border border-none mt-3'>Submit</button>
                                                                              </form>
                                                             </div>       
                                                      
                                                </div>
                                              
                                          </div>
                                      
                                 </section>
                                   
                              </>
                          )
                  })
               }
            </>
      )
}
    export default Home